#SKD101|iview|28|2014.11.16 01:59:42|25603|185|4355|127|1|5|1|3|14|1|5|346|179|20365|4|12

DROP TABLE IF EXISTS `vass_albums`;
CREATE TABLE `vass_albums` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tag` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `artist_id` int(8) NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `name` varchar(50) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `composer_id` int(11) NOT NULL,
  `descr` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `playcount` smallint(8) NOT NULL DEFAULT '0',
  `like` tinyint(9) NOT NULL DEFAULT '0',
  `view` smallint(9) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `name` (`name`),
  KEY `artist_id` (`artist_id`)
) ENGINE=MyISAM AUTO_INCREMENT=186 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `vass_albums` VALUES